from ibapi.client import EClient
from ibapi.wrapper import EWrapper
from ibapi.contract import Contract
from ibapi.order import *

import threading
import time

class IBapi(EWrapper, EClient):
	def __init__(self):
		EClient.__init__(self, self)

	def nextValidId(self, orderId: int):
		super().nextValidId(orderId)
		self.nextorderId = orderId
		print('The next valid order id is: ', self.nextorderId)

	def orderStatus(self, orderId, status, filled, remaining, avgFullPrice, permId, parentId, lastFillPrice, clientId, whyHeld, mktCapPrice):
		print('orderStatus - orderid:', orderId, 'status:', status, 'filled', filled, 'remaining', remaining, 'lastFillPrice', lastFillPrice)
	
	def openOrder(self, orderId, contract, order, orderState):
		print('openOrder id:', orderId, contract.symbol, contract.secType, '@', contract.exchange, ':', order.action, order.orderType, order.totalQuantity, orderState.status)

	def execDetails(self, reqId, contract, execution):
		print('Order Executed: ', reqId, contract.symbol, contract.secType, contract.currency, execution.execId, execution.orderId, execution.shares, execution.lastLiquidity)


def run_loop():
	app.run()

#Function to create FX Order contract
def FX_order():
	# contract = Contract()
	# contract.symbol = symbol[:3]
	# contract.secType = 'CASH'
	# contract.exchange = 'IDEALPRO'
	# contract.currency = symbol[3:]
	contract = Contract()
	contract.symbol = "AAPL"
	contract.secType = "OPT" #SET FOR OPTIONS
	contract.exchange = "SMART" #IBKR Smart Routing
	contract.currency = "USD"
	contract.lastTradeDateOrContractMonth = "20230623" #Expiration
	contract.strike = 185
	contract.right = "C"
	contract.multiplier = "100"

	return contract

app = IBapi()
app.connect('127.0.0.1', 7496, 1)

app.nextorderId = None

#Start the socket in a thread
api_thread = threading.Thread(target=run_loop, daemon=True)
api_thread.start()

#Check if the API is connected via orderid
while True:
	if isinstance(app.nextorderId, int):
		print('connected')
		break
	else:
		print('waiting for connection')
		time.sleep(1)

#Create order object
order = Order()
order.action = 'BUY'
order.totalQuantity = 1
order.orderType = 'LMT'

order.lmtPrice = '1.10'
order.eTradeOnly = False
order.firmQuoteOnly = False
#Place order
app.placeOrder(app.nextorderId, FX_order(), order)
#app.nextorderId += 1

time.sleep(3)

#Cancel order 
# print('cancelling order')
# app.cancelOrder(app.nextorderId)

time.sleep(3)
app.disconnect()